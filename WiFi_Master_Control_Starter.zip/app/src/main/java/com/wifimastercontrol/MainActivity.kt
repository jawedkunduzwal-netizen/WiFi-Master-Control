package com.wifimastercontrol

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class DemoDevice(
    val name: String,
    val ip: String,
    val mac: String,
    val speed: String,
    val blocked: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WiFiMasterApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WiFiMasterApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var showInfo by remember { mutableStateOf(true) }
    var routerAddress by remember { mutableStateOf("192.168.1.1") }
    var devices by remember {
        mutableStateOf(
            listOf(
                DemoDevice("زما موبایل", "192.168.1.2", "AA:BB:CC:11:22:01", "بې محدودیته"),
                DemoDevice("مهمان ۱", "192.168.1.3", "AA:BB:CC:11:22:02", "بې محدودیته"),
                DemoDevice("مهمان ۲", "192.168.1.4", "AA:BB:CC:11:22:03", "بې محدودیته")
            )
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF49D6C5),
            secondary = androidx.compose.ui.graphics.Color(0xFF8DB9FF),
            background = androidx.compose.ui.graphics.Color(0xFF0B1220),
            surface = androidx.compose.ui.graphics.Color(0xFF141E2E)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("WiFi Master Control", fontWeight = FontWeight.Bold)
                            Text("د وای فای مدیریت", style = MaterialTheme.typography.labelMedium)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Wifi, contentDescription = null) },
                        label = { Text("شبکه") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Devices, contentDescription = null) },
                        label = { Text("وسایل") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Speed, contentDescription = null) },
                        label = { Text("سرعت") }
                    )
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            when (selectedTab) {
                0 -> NetworkScreen(
                    modifier = Modifier.padding(padding),
                    routerAddress = routerAddress,
                    onAddressChange = { routerAddress = it },
                    deviceCount = devices.count { !it.blocked },
                    showInfo = showInfo,
                    onDismissInfo = { showInfo = false }
                )
                1 -> DevicesScreen(
                    modifier = Modifier.padding(padding),
                    devices = devices,
                    onToggleBlock = { target ->
                        devices = devices.map {
                            if (it.mac == target.mac) it.copy(blocked = !it.blocked) else it
                        }
                    }
                )
                else -> SpeedScreen(Modifier.padding(padding), devices)
            }
        }
    }
}

@Composable
private fun NetworkScreen(
    modifier: Modifier,
    routerAddress: String,
    onAddressChange: (String) -> Unit,
    deviceCount: Int,
    showInfo: Boolean,
    onDismissInfo: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Router, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("زما شبکه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("د روټر د نښلولو لومړنی سکرین", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    OutlinedTextField(
                        value = routerAddress,
                        onValueChange = onAddressChange,
                        label = { Text("د روټر IP پته") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                        Text("د روټر نښلول")
                    }
                    Text("دا اوس د ډیزاین نمونه ده؛ لا تر اوسه روټر نه نښلوي.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("وصل وسایل", "$deviceCount", Modifier.weight(1f))
                MetricCard("روټرونه", "0", Modifier.weight(1f))
            }
        }
        if (showInfo) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("د ریموټ کنټرول یادونه", fontWeight = FontWeight.Bold)
                        Text("له کوره بهر کنټرول لپاره خوندي سرور یا VPN او د روټر/شبکې اړخ ملاتړ ته اړتیا ده. د هر روټر ټول امکانات تضمین کېدای نه شي.")
                        TextButton(onClick = onDismissInfo) { Text("سمه ده") }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DevicesScreen(
    modifier: Modifier,
    devices: List<DemoDevice>,
    onToggleBlock: (DemoDevice) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("وصل شوي وسایل", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("دا یوازې د نمونې وسایل دي؛ له حقیقي روټر څخه نه دي لوستل شوي.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        items(devices, key = { it.mac }) { device ->
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(device.name, fontWeight = FontWeight.Bold)
                            Text("IP: ${device.ip}", style = MaterialTheme.typography.bodySmall)
                            Text("MAC: ${device.mac}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (device.blocked) "بند" else "وصل", color = if (device.blocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                    OutlinedButton(onClick = { onToggleBlock(device) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (device.blocked) "له نمونې بندیزه وباسه" else "وسیله بنده کړه (نمونه)")
                    }
                }
            }
        }
    }
}

@Composable
private fun SpeedScreen(modifier: Modifier, devices: List<DemoDevice>) {
    var chosen by remember { mutableStateOf("مهمان ۱") }
    var download by remember { mutableFloatStateOf(1f) }
    var upload by remember { mutableFloatStateOf(0.5f) }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("د سرعت محدودول", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("وسیله انتخاب کړه او د نمونې حد وټاکه.")
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                devices.filter { !it.blocked }.forEach { device ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = chosen == device.name, onClick = { chosen = device.name })
                        Text(device.name)
                    }
                }
                Divider()
                Text("Download: ${download.toInt()} Mbps")
                Slider(value = download, onValueChange = { download = it }, valueRange = 0.1f..10f)
                Text("Upload: ${(upload * 10).toInt() / 10.0} Mbps")
                Slider(value = upload, onValueChange = { upload = it }, valueRange = 0.1f..5f)
                Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("سرعت ثبت کړه") }
                Text("دا یوازې د سکرین نمونه ده؛ د سرعت حد لا روټر ته نه لېږي.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
